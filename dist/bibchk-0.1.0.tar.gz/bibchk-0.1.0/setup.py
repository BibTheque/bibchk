# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bibchk']

package_data = \
{'': ['*']}

install_requires = \
['argparse>=1.4.0,<2.0.0', 'habanero>=1.0.0,<2.0.0', 'isbnlib>=3.10.10,<4.0.0']

setup_kwargs = {
    'name': 'bibchk',
    'version': '0.1.0',
    'description': 'Simple command line program to return the BibTeX string of a given DOI or ISBN.',
    'long_description': None,
    'author': 'Doug Keller',
    'author_email': 'dg.kllr.jr@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
